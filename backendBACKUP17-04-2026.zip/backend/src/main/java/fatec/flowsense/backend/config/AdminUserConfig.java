package fatec.flowsense.backend.config;

import fatec.flowsense.backend.entities.Role;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import fatec.flowsense.backend.repository.RoleRepository;
import fatec.flowsense.backend.repository.UserRepository;
import jakarta.transaction.Transactional;

@Configuration
public class AdminUserConfig implements CommandLineRunner{
	
	
	private RoleRepository roleRepository;
	
	private UserRepository userRepository;
	
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	
	
	public AdminUserConfig(RoleRepository roleRepository,
						   UserRepository userRepository,
						   BCryptPasswordEncoder bCryptPasswordEncoder) {
		this.roleRepository = roleRepository;
		this.userRepository = userRepository;
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	
	
	
	@Override
	@Transactional
	public void run(String...args) throws Exception{
		
		var roleAdmin = roleRepository.findByName(Role.Values.ADMIN.name());
		
	}

}
